<?php

phpinfo();
echo 1 + 1
echo "cool 4 typing"

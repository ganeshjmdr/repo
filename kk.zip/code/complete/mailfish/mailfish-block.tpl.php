<?php
/**
 * @file
 *   Themes the mailfish block.  
 */
?>
<div id='mailfish-rocks'>
  Check it out:
  <?php print $rendered_form; ?>
</div>

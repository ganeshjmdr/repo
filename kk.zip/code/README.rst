Module Development code samples
===============================

This directory contains code samples used in the Introduction to module development course by Acquia.

*complete*
  Contains completed coppies of the modules used in the course

*steps*
  Contains the mailfish module as it should look at the beginning of each session

*snippets*
  Contains the code used in each example in the manual, organized by session.

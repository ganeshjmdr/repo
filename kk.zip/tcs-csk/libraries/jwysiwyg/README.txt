jWYSIWYG
========

Copyright (c) 2009 Juan M Martínez
Dual licensed under the MIT (MIT-license.txt)
and GPL (GPL-license.txt) licenses.

REQUIREMENTS
============

jQuery 1.3 or higher.

ENVIRONMENT
===========

Tested in Safari 4, Firefox 3.5, Chrome 4.0, Internet Explorer 8.

Some minor bugs still exist while 1.0 not reached.

WEB SITE
========

http://code.google.com/p/jwysiwyg/
